export enum appConfig{
    companyLatitude = 53.339428,
    companyLongitude = -6.257664
}