export const environment = {
  production: true,
  url: 'https://s3.amazonaws.com/'
};
